param (
    [Parameter(Mandatory = $true)][string]$drive,
    [string]$batchId = (Get-Date -format "yyyy-MM-dd_hh-mm-ss"),
    [string]$testSize = '1G',
    [int]$durationSec = 5,
    [int]$warmupSec = 1,
    [int]$cooldownSec = 1,
    [int]$restSec = 1,
    [string]$diskspd = 'C:\Users\user\Desktop\diskspd-amd64\diskspd.exe'
)


function Get-TestSummary {
    param ($test, $xmlFilePath, $driveObj)
    
    $xml = [xml](Get-Content $xmlFilePath)
    $summary = New-Object psobject

    
    # Test meta data
    $summary | Add-Member -MemberType NoteProperty -Name 'ComputerName' -Value $xml.Results.System.ComputerName
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Drive' -Value $driveObj.Name
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Drive VolumeLabel' -Value $driveObj.VolumeLabel
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Batch' -Value $batchId
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Test Time' -Value (Get-Date)
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Test Name' -Value $test.name

    
    # IO meta data
    $summary | Add-Member -MemberType NoteProperty -Name 'Test File Size' -Value $testSize
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Duration [s]' -Value $durationSec
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Warmup [s]' -Value $warmupSec
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Cooldown [s]' -Value $cooldownSec
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Test Params' -Value $test.params

    
    # IO metrics
    $summary | Add-Member -MemberType NoteProperty -Name 'TestTimeSeconds' -Value $xml.Results.TimeSpan.TestTimeSeconds
    
    $summary | Add-Member -MemberType NoteProperty -Name 'WriteRatio' -Value ($xml.Results.Profile.TimeSpans.TimeSpan.Targets.Target.WriteRatio | Select-Object -First 1)
    
    $summary | Add-Member -MemberType NoteProperty -Name 'ThreadCount' -Value $xml.Results.TimeSpan.ThreadCount
    
    $summary | Add-Member -MemberType NoteProperty -Name 'RequestCount' -Value ($xml.Results.Profile.TimeSpans.TimeSpan.Targets.Target.RequestCount | Select-Object -First 1)
    
    $summary | Add-Member -MemberType NoteProperty -Name 'BlockSize' -Value ($xml.Results.Profile.TimeSpans.TimeSpan.Targets.Target.BlockSize | Select-Object -First 1)

    
    # Summing read and write iops
    $summary | Add-Member -MemberType NoteProperty -Name 'ReadCount' -Value (($xml.Results.TimeSpan.Thread.Target | Measure-Object -Sum -Property ReadCount).Sum)
    
    $summary | Add-Member -MemberType NoteProperty -Name 'WriteCount' -Value (($xml.Results.TimeSpan.Thread.Target | Measure-Object -Sum -Property WriteCount).Sum)
    
    $summary | Add-Member -MemberType NoteProperty -Name 'ReadBytes' -Value (($xml.Results.TimeSpan.Thread.Target | Measure-Object -Sum -Property ReadBytes).Sum)
    
    $summary | Add-Member -MemberType NoteProperty -Name 'WriteBytes' -Value (($xml.Results.TimeSpan.Thread.Target | Measure-Object -Sum -Property WriteBytes).Sum)

    
    # Latency metrics
    $percentiles = @(25, 50, 75, 90, 95, 99, 99.9, 100)
    $latencyData = @{}
    $xml.Results.TimeSpan.Latency.Bucket | ForEach-Object { $latencyData[$_.Percentile] = $_ }

    
    foreach ($percentile in $percentiles) {
        $bucket = $latencyData[$percentile]
        
        $summary | Add-Member -MemberType NoteProperty -Name ("{0}% r" -f $percentile) -Value $bucket.ReadMilliseconds
        
        $summary | Add-Member -MemberType NoteProperty -Name ("{0}% w" -f $percentile) -Value $bucket.WriteMilliseconds
    }

    
    return $summary
}



function Summarize-Tests {
    param ($tests)
    
    $summary = New-Object psobject


    # Drive meta data
    $summary | Add-Member -MemberType NoteProperty -Name 'ComputerName' -Value $tests[0].ComputerName
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Drive' -Value $tests[0].Drive
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Drive VolumeLabel' -Value $tests[0].'Drive VolumeLabel'
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Batch' -Value $tests[0].Batch
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Test Time' -Value $tests[0].'Test Time'
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Test File Size' -Value $tests[0].'Test File Size'
    
    $summary | Add-Member -MemberType NoteProperty -Name 'Test Duration [s]' -Value $tests[0].'Duration [s]'


    # IO performance summary
    $tests | ForEach-Object {
        $type = $_.'Test Name'
        
        $readMBps = $_.ReadBytes / $_.'TestTimeSeconds' / 1MB
        $writeMBps = $_.WriteBytes / $_.'TestTimeSeconds' / 1MB


        switch ($type) {
            'Sequential read' { $summary | Add-Member -MemberType NoteProperty -Name 'Sequential Read 1MB [MB/s]' -Value $readMBps }
            'Sequential write' { $summary | Add-Member -MemberType NoteProperty -Name 'Sequential Write 1MB [MB/s]' -Value $writeMBps }
            'Random read' { $summary | Add-Member -MemberType NoteProperty -Name 'Random Read 4KB (QD=1) [MB/s]' -Value $readMBps }
            'Random write' { $summary | Add-Member -MemberType NoteProperty -Name 'Random Write 4KB (QD=1) [MB/s]' -Value $writeMBps }
            'Random QD32 read' { $summary | Add-Member -MemberType NoteProperty -Name 'Random Read 4KB (QD=32) [MB/s]' -Value $readMBps }
            'Random QD32 write' { $summary | Add-Member -MemberType NoteProperty -Name 'Random Write 4KB (QD=32) [MB/s]' -Value $writeMBps }
        }
    }

    return $summary
}



# Initialize test file
$testFileParams = "{0}benchmark.tmp" -f $drive

$xmlFile = "{0}-Generation.xml" -f $batchId

$params = "-Rxml -d1 -S -Z1M -c{0}" -f $testSize + " " + $testFileParams

Write-Host $params
Write-Host $xmlFile
& $diskspd $params.Split(" ") > $xmlFile



# Fixed parameters for tests
$fixedParams = '-L -S -Rxml'
$batchAutoParam = "-d{0} -W{1} -C{2}" -f $durationSec, $warmupSec, $cooldownSec


Remove-Item $xmlFile -ErrorAction SilentlyContinue


# Iterate over tests
$tests = @()


$testConfigs = @(
    @{ name = 'Sequential read'; params = '-b1M -o1 -t1 -w0 -Z1M' },
    @{ name = 'Sequential write'; params = '-b1M -o1 -t1 -w100 -Z1M' },
    @{ name = 'Random read'; params = '-b4K -o1 -t1 -r -w0 -Z1M' },
    @{ name = 'Random write'; params = '-b4K -o1 -t1 -r -w100 -Z1M' },
    @{ name = 'Random QD32 read'; params = '-b4K -o32 -t1 -r -w0 -Z1M' },
    @{ name = 'Random QD32 write'; params = '-b4K -o32 -t1 -r -w100 -Z1M' }
)



foreach ($test in $testConfigs) {
    $params = "$fixedParams $batchAutoParam $test.params $testFileParams"
    $xmlFile = "{0}-{1}.xml" -f $batchId, $test.name
    Write-Host $params
    Write-Host $xmlFile
    Start-Sleep -Seconds $restSec
    & $diskspd $params.Split(" ") > $xmlFile

    $driveObj = [System.IO.DriveInfo]::GetDrives() | Where-Object { $_.Name -eq $drive }
    $testResult = Get-TestSummary $test $xmlFile $driveObj
    $tests += $testResult

    Remove-Item $xmlFile -ErrorAction SilentlyContinue
}


# Export results to CSV
Remove-Item 'diskspd-result.csv' -ErrorAction SilentlyContinue
$tests | Export-Csv 'diskspd-result.csv' -NoTypeInformation


# Summarize and output
$testsSum = Summarize-Tests $tests
$testsSum

#reference for script was here https://github.com/ayavilevich/DiskSpdAuto