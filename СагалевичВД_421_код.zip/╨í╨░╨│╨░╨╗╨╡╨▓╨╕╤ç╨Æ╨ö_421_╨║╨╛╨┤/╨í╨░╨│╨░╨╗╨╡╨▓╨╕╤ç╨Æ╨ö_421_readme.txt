Для воспроизведения работы необходимо рабочее место с установленной ОС «Фантом». Минимальные требования для запуска скрипта «single_vm_test.sh»соответствуют минимальным требованиям этой ос. Для запуска «multiple_vm_test.sh» необходимо минимум 16Гб оперативной памяти. 
Должны быть установлены пакеты:
apt install samba
apt install nbd-server
apt install nbd-client
apt install nfs-common
apt install nfs-kernel-server
apt install zfs-dkms
apt install iperf
apt install iproute2
apt install ssh
Для каждого протокола необходимо создать/редактировать файл .conf, в которых необходимо указать путь для совместного доступа и добавить в группу доступа пользователей ВМ. 
Необходим образ виртуальный машины Windows 7. На нее нужно установить бенчмарк diskspd, а также скрипты «onboot.cmd», «BenchmarkDrive.ps1». Необходимо в планировщике задач указать, чтобы скрипт «onboot.cmd» исполнялся при запуске ВМ. Он будет исполнять скрипт «BenchTest.ps1». 

Скрипт «single_vm_test.sh» используется для тестирования с одной виртуальной машиной. В зависимости от конфигурации, в нем необходимо отредактировать переменные local_iface, local_address, remote_iface, remote_address. 
Для запуска использовать: 
chmod +x single_vm_test.sh
./single_vm_test.sh

Скрипт «multiple_vm_test.sh» используется для тестирования с несколькими виртуальными машинами. Необходимо отредактировать local_iface, local_address, remote_addresses, user_map, iface_map. 
Необходимо, чтобы в каталоге со скриптами были созданы каталоги data, result
Для запуска использовать: 
chmod +x multiple_vm_test.sh
./multiple_vm_test.sh