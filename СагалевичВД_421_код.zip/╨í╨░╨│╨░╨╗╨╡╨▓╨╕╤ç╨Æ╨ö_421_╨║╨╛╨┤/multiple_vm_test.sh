#!/bin/bash
set -eu
IFS=$'\n\t'

data_path=$(realpath data)

# Заранее создать каталог 'data'
if [ ! -d "$data_path" ]; then
    echo "Directory named 'data' must exist" >&2
    exit 1
fi

results_path=$(pwd)/results
mkdir -p "$results_path"

local_iface=vif1.0-emu # Редактировать в зависимости от конфигурации
local_address=10.127.1.1  # Редактировать в зависимости от конфигурации
remote_addresses=(10.127.1.2 10.127.1.3 10.127.1.4 10.127.1.5) # user0, user1, user2, user3
pids=()

# Ассоциативный массив для соответствия IP-адресов и имен пользователей
declare -A user_map=(
    [10.127.1.2]="user0"  # Редактировать в зависимости от конфигурации
    [10.127.1.3]="user1"  # Редактировать в зависимости от конфигурации
    [10.127.1.4]="user2"  # Редактировать в зависимости от конфигурации
    [10.127.1.5]="user3"  # Редактировать в зависимости от конфигурации
)

# Ассоциативный массив для соответствия IP-адресов и интерфейсов
declare -A iface_map=(
    [10.127.1.2]="vif1.1-emu"  # Редактировать в зависимости от конфигурации
    [10.127.1.3]="vif1.2-emu"  # Редактировать в зависимости от конфигурации
    [10.127.1.4]="vif1.3-emu"  # Редактировать в зависимости от конфигурации
    [10.127.1.5]="vif1.4-emu"  # Редактировать в зависимости от конфигурации
)

process_with_pid_exists() {
    kill -0 $1 2>/dev/null
}

stop_servers() {
    for pid in "${pids[@]}"; do
        if process_with_pid_exists $pid; then
            echo "--== Killing PID: $pid"
            kill "$pid" || true
        fi
    done
}

start_servers() {
    smbd -F --configfile=smb.conf &
    pids+=($!)

    sleep 0.125
    process_with_pid_exists $! || return 1
    echo "--== Started SMB: ${pids[-1]}"

    nbd-server 2000 "$data_path/disk.raw" -C nbd.conf -d &
    pids+=($!)

    sleep 0.125
    process_with_pid_exists $! || return 1
    echo "--== Started NBD: ${pids[-1]}"

    # NFS сконфигурирован в каталоге /etc/exports
    # /srv/ftp/share_pkz/netdrivetest/data       10.0.0.2(rw,all_squash,anonuid=1000,anongid=1000)
    # $data_path       ${remote_addresses[*]}(rw,all_squash,anonuid=1000,anongid=1000)
}

remote_cmd() {
    local address=$1
    shift
    ssh -i id_rsa "root@$address" "$@"
}

remote_collect_machine_info() {
    local address=$1
    local result_path=$2

    remote_cmd $address lspci > "$result_path/lspci.txt"
    remote_cmd $address lsusb > "$result_path/lsusb.txt"
    remote_cmd $address lshw > "$result_path/lshw.txt"
    remote_cmd $address cat /proc/cpuinfo > "$result_path/cpuinfo.txt"

    # запуск iperf для UDP
    iperf -s -u &
    local iperf_pid=$!
    process_with_pid_exists $iperf_pid || return 1
    remote_cmd $address iperf -c "$local_address" -u -b 1G -r > "$result_path/iperf-udp-1G.txt"
    kill $iperf_pid

    # запуск iperf для TCP
    iperf -s &
    local iperf_pid=$!
    process_with_pid_exists $iperf_pid || return 1
    remote_cmd $address iperf -c "$local_address" -r > "$result_path/iperf-tcp.txt"
    kill $iperf_pid
}

remote_umount_all() {
    local address=$1

    echo "--== Unmounting remote disk on $address"

    remote_cmd $address umount "/mnt/data_nfs" || true

    remote_cmd $address "rm /mnt/data_nbd/disk.raw" &>/dev/null || true

    remote_cmd $address nbd-client -d /dev/nbd0 || true

    remote_cmd $address umount "/mnt/data_smb" || true
}

remote_mount_all() {
    local address=$1
    local remote_iface=${iface_map[$address]}

    echo "--== Mounting smb on $address"

    remote_cmd $address "mkdir -p /mnt/data_smb" || return 1

    remote_cmd $address "mount -t cifs -o guest,iocharset=utf8 '//$local_address/data' /mnt/data_smb" || return 1

    echo "--== Mounting nbd on $address"

    remote_cmd $address modprobe nbd || return 1

    remote_cmd $address mkdir -p /mnt/data_nbd || return 1

    remote_cmd $address "nbd-client -name '' '$local_address' 2000 /dev/nbd0" || return 1

    remote_cmd $address "ln -sf /dev/nbd0 /mnt/data_nbd/disk.raw" || return 1

    echo "--== Mounting nfs on $address"

    remote_cmd $address mkdir -p /mnt/data_nfs || return 1

    remote_cmd $address "mount '$local_address:$data_path' /mnt/data_nfs" || return 1

    remote_cmd $address "mkdir -p /mnt/data_local" || return 1
}

remote_cache_prepare() {
    local address=$1
    remote_cmd $address "sync; echo 1 > /proc/sys/vm/drop_caches"
}

get_iface_rx_bytes() {
    ip -s link show $1 | tail -n 3 | head -n 1 | cut -d' ' -f 5
}

get_iface_tx_bytes() {
    ip -s link show $1 | tail -n 1 | head -n 1 | cut -d' ' -f 5
}

get_iface_rx_packets() {
    ip -s link show $1 | tail -n 3 | head -n 1 | cut -d' ' -f 6
}

get_iface_tx_packets() {
    ip -s link show $1 | tail -n 1 | head -n 1 | cut -d' ' -f 6
}

write_csv_header=true
tests_run_number=100

run_test() {
    local address=$1
    local result_path=$2
    local method=$3
    local volatility=$4
    local latency=$5
    local xfer_rate=$6

    # Определение PKZ_USER_NAME на основе IP-адреса
    local PKZ_USER_NAME=${user_map[$address]}

    echo "--== Running test on $address: method $method, volatility $volatility, latency $latency, transfer rate $xfer_rate"

    remote_cache_prepare $address

    /usr/bin/time --format="%e" --output="$result_path/boottime" nc -l -p 2001 -q 0 -o /dev/null &

    local test_start_rx_bytes=$(get_iface_rx_bytes $local_iface)
    local test_start_tx_bytes=$(get_iface_tx_bytes $local_iface)

    local test_start_rx_packets=$(get_iface_rx_packets $local_iface)
    local test_start_tx_packets=$(get_iface_tx_packets $local_iface)

    local test_start_time=$(date "+%s")

    if ! remote_cmd $address "DISPLAY=:0 PKZ_USER_NAME=$PKZ_USER_NAME /usr/lib/pkz/pkz-start-user-vm $volatility /mnt/data_$method/disk.raw"; then
        echo "--== Failed to start test on $address"
        return 1
    fi

    local test_end_time=$(date "+%s")
    local test_time=$(( $test_end_time - $test_start_time ))

    local test_end_rx_bytes=$(get_iface_rx_bytes $local_iface)
    local test_end_tx_bytes=$(get_iface_tx_bytes $local_iface)

    local test_end_rx_packets=$(get_iface_rx_packets $local_iface)
    local test_end_tx_packets=$(get_iface_tx_packets $local_iface)

    local test_rx_bytes=$(( "$test_end_rx_bytes" - "$test_start_rx_bytes" ))
    local test_tx_bytes=$(( "$test_end_tx_bytes" - "$test_start_tx_bytes" ))

    local test_rx_packets=$(( "$test_end_rx_packets" - "$test_start_rx_packets" ))
    local test_tx_packets=$(( "$test_end_tx_packets" - "$test_start_tx_packets" ))

    if $write_csv_header; then
        local header="IP,Tests run number,Tests run time (s),Method,Volatility,Latency (ms),Xfer rate (mbit/s),Boot time (s),RX bytes,TX bytes,RX packets,TX packets,"$(head -n 1 "$result_path/diskspd")
        echo "$header" > "$result_path/tests_results.csv"
        write_csv_header=false
    fi

    local boottime=$(cat "$result_path/boottime")

    local csv_line_prefix="$address,$tests_run_number,$test_time,$method,$volatility,$latency,${xfer_rate//mbit/},$boottime,$test_rx_bytes,$test_tx_bytes,$test_rx_packets,$test_tx_packets,"

    while IFS='' read -r csv_line; do
        echo "$csv_line_prefix$csv_line" >> "$result_path/tests_results.csv"
    done <<< $(tail -n +2 "$result_path/diskspd")

    tests_run_number=$(( $tests_run_number + 1 ))
    echo "--== Test finished on $address in $test_time seconds"
}

run_tests_on_machine() {
    local address=$1
    local result_path=$2

    if ! ping -c 1 -W 1 "$address" &>/dev/null; then
        echo "--== Remote address $address is unreachable"
        return 1
    fi

    if ! mkdir -p "$result_path"; then
        echo "--== Failed to create results path for $address"
        return 1
    fi

    if ! remote_collect_machine_info $address $result_path; then
        echo "--== Failed to collect machine info for $address"
        return 1
    fi

    if start_servers; then
        if remote_mount_all $address; then

            echo "--== Starting tests on $address!"

            for method in smb; do
                if [ "$method" = "local" ]; then
                    echo "--== Initializing data for 'local' method on $address"

                    if ! remote_cmd $address "cp -n /mnt/data_smb/disk.raw /mnt/data_local/"; then
                        echo "--== Failed to initialize data on $address, skipping test"

                        continue
                    fi
                fi

                for volatility in volatile-slow; do
                    for latency in 0 5 10 15; do
                        if [ ! "$latency" = "0" ] && [ "$method" = "local" ]; then
                            echo "--== Skipping latency $latency for local method on $address"

                            continue
                        fi

                        if ! tc qdisc add dev $local_iface root handle 1: netem delay ${latency}ms; then
                            echo "--== Failed to set latency $latency, skipping test on $address"

                            continue
                        fi

                        for xfer_rate in 25mbit 50mbit 75mbit 100mbit 150mbit 200mbit 1000mbit; do
                            if [ ! "$xfer_rate" = "1000mbit" ] && [ "$method" = "local" ]; then
                                echo "--== Skipping transfer rate $xfer_rate for local method on $address"

                                continue
                            fi

                            if ! tc qdisc add dev $local_iface parent 1: tbf rate $xfer_rate latency 200ms burst 131072; then
                                echo "--== Failed to set transfer rate $xfer_rate, skipping test on $address"

                                continue
                            fi

                            local remote_iface=${iface_map[$address]}
                            if ! remote_cmd $address tc qdisc add dev $remote_iface root tbf rate $xfer_rate latency 200ms burst 131072; then
                                echo "--== Failed to set transfer rate $xfer_rate on remote machine $address, skipping test"

                                continue
                            fi

                            run_test $address $result_path $method $volatility $latency $xfer_rate || true

                            remote_cmd $address tc qdisc del dev $remote_iface root tbf rate $xfer_rate latency 200ms burst 131072 || true
                            tc qdisc del dev $local_iface parent 1: tbf rate $xfer_rate latency 200ms burst 131072 || true
                        done

                        tc qdisc del dev $local_iface root netem || true

                    done
                done
            done
        fi

        remote_umount_all $address
    fi

    stop_servers
}

main() {
    for remote_address in "${remote_addresses[@]}"; do
        result_path="$results_path/$remote_address"

        run_tests_on_machine $remote_address $result_path &

    done
    wait
}

main

chown -R 1000:1000 "$results_path"

echo "Done!"
