#!/bin/bash
set -eu
IFS=$'\n\t'

data_path=$(realpath data)

if [ ! -d "$data_path" ]; then
	echo "Directory named 'data' must exist" >&2
	exit 1
fi

results_path=$(pwd)/results
results_csv=$results_path/tests_results.csv

local_iface=vif1.0-emu # Редактировать в зависимости от конфигурации
local_address=10.127.1.1 # Редактировать в зависимости от конфигурации

remote_iface=vif1.0-emu # Редактировать в зависимости от конфигурации
remote_address=${1:-10.127.1.2} # Редактировать в зависимости от конфигурации

server_pid_smb=
server_pid_nbd=
server_pid_nfs=

process_with_pid_exists() {
	kill -0 $1 2>/dev/null
}

stop_servers() {
	if [ ! -z "$server_pid_smb" ]; then
		echo "--== Killing SMB: $server_pid_smb"
		kill "$server_pid_smb" || true
	fi
	
	if [ ! -z "$server_pid_nbd" ]; then
		echo "--== Killing NBD: $server_pid_nbd"
		kill "$server_pid_nbd" || true
	fi
	
	if [ ! -z "$server_pid_nfs" ]; then
		echo "--== Killing NFS: $server_pid_nfs"
		kill "$server_pid_nfs" || true
	fi
}

start_servers() {
	smbd -F --configfile=smb.conf &
	server_pid_smb=$!
    
	sleep 0.125
	process_with_pid_exists $server_pid_smb || return 1
	echo "--== Started SMB: $server_pid_smb"
	
	nbd-server 2000 "$data_path/disk.raw" -C nbd.conf -d &
	server_pid_nbd=$!
    
	sleep 0.125
    
	process_with_pid_exists $server_pid_nbd || return 1
	echo "--== Started NBD: $server_pid_nbd"
    
    # NFS сконфигурирован в каталоге /etc/exports
    # /srv/ftp/share_pkz/netdrivetest/data       10.0.0.2(rw,all_squash,anonuid=1000,anongid=1000)
    # $data_path       ${remote_addresses[*]}(rw,all_squash,anonuid=1000,anongid=1000)
}


remote_cmd() {
	ssh -i id_rsa "root@$remote_address" "$@"
}

remote_collect_machine_info() {
	remote_cmd lspci > "$results_path/lspci.txt"
	remote_cmd lsusb > "$results_path/lsusb.txt"
	remote_cmd lshw > "$results_path/lshw.txt"
	remote_cmd cat /proc/cpuinfo > "$results_path/cpuinfo.txt"
    
    #making delay with iperf
	# UDP iperf
	iperf -s -u &
	local iperf_pid=$!
	process_with_pid_exists $iperf_pid || return 1
	remote_cmd iperf -c "$local_address" -u -b 1G -r > "$results_path/iperf-udp-1G.txt"
	kill $iperf_pid

    #makng delay with iperf
	# TCP iperf
	iperf -s &
	local iperf_pid=$!
	process_with_pid_exists $iperf_pid || return 1
	remote_cmd iperf -c "$local_address" -r > "$results_path/iperf-tcp.txt"
	kill $iperf_pid
}


remote_umount_all() {
	echo "--== Unmounting remote disk"
	
	remote_cmd umount "/mnt/data_nfs" || true
	
	remote_cmd "rm /mnt/data_nbd/disk.raw" &>/dev/null || true
	
	remote_cmd nbd-client -d /dev/nbd0 || true
	
	remote_cmd umount "/mnt/data_smb" || true
}

# mount vm to server

remote_mount_all() {
	echo "--== Mounting smb"
	
	remote_cmd "mkdir -p /mnt/data_smb" || return 1
	
	remote_cmd "mount -t cifs -o guest,iocharset=utf8 '//$local_address/data' /mnt/data_smb" || return 1
	
    
	echo "--== Mounting nbd"
	
	remote_cmd modprobe nbd || return 1
	
	remote_cmd mkdir -p /mnt/data_nbd || return 1
	
	remote_cmd "nbd-client -name '' '$local_address' 2000 /dev/nbd0" || return 1
	
	remote_cmd "ln -sf /dev/nbd0 /mnt/data_nbd/disk.raw" || return 1

        
	echo "--== Mounting nfs"
	
	remote_cmd mkdir -p /mnt/data_nfs || return 1
	
	remote_cmd "mount '$local_address:$data_path' /mnt/data_nfs" || return 1
    
    #remote_cmd "mount -t nfs -o"
	
	remote_cmd "mkdir -p /mnt/data_local" || return 1
}

remote_cache_prepare() {
	#echo "--== Preparing remote machine cache: $1"
	
	remote_cmd "sync; echo 1 > /proc/sys/vm/drop_caches"
        #remote_cmd dd if=/mnt/data_$1/disk.raw of=/dev/null bs=1M count=512
}

get_iface_rx_bytes() {
	ip -s link show $1 | tail -n 3 | head -n 1 | cut -d' ' -f 5
}

get_iface_tx_bytes() {
	ip -s link show $1 | tail -n 1 | head -n 1 | cut -d' ' -f 5
}

get_iface_rx_packets() {
	ip -s link show $1 | tail -n 3 | head -n 1 | cut -d' ' -f 6
}

get_iface_tx_packets() {
	ip -s link show $1 | tail -n 1 | head -n 1 | cut -d' ' -f 6
}

write_csv_header=
tests_run_number=57

run_test() {
    #params for test
	local method=$1
	local volatility=$2
	local latency=$3
	local   _rate=$4
	
	echo "--== Running test: method $method, volatility $volatility, latency $latency, transfer rate $xfer_rate"
	
    # Clear cache before every test batch
	remote_cache_prepare $method
	
	/usr/bin/time --format="%e" --output="$results_path/boottime" nc -l -p 2001 -q 0 -o /dev/null &
	#nc -l -p 2002 -q 0 > "$results_path/diskspd" &

	local test_start_rx_bytes=$(get_iface_rx_bytes $local_iface)
	local test_start_tx_bytes=$(get_iface_tx_bytes $local_iface)

	local test_start_rx_packets=$(get_iface_rx_packets $local_iface)
	local test_start_tx_packets=$(get_iface_tx_packets $local_iface)

	local test_start_time=$(date "+%s")

	if ! remote_cmd "DISPLAY=:0 PKZ_USER_NAME=user0 /usr/lib/pkz/pkz-start-user-vm $volatility /mnt/data_$method/disk.raw"; then
		echo "--== Failed to start test"

		return 1
	fi

	local test_end_time=$(date "+%s")
	local test_time=$(( $test_end_time - $test_start_time ))

	local test_end_rx_bytes=$(get_iface_rx_bytes $local_iface)
	local test_end_tx_bytes=$(get_iface_tx_bytes $local_iface)

	local test_end_rx_packets=$(get_iface_rx_packets $local_iface)
	local test_end_tx_packets=$(get_iface_tx_packets $local_iface)

	local test_rx_bytes=$(( "$test_end_rx_bytes" - "$test_start_rx_bytes" ))
	local test_tx_bytes=$(( "$test_end_tx_bytes" - "$test_start_tx_bytes" ))

	local test_rx_packets=$(( "$test_end_rx_packets" - "$test_start_rx_packets" ))
	local test_tx_packets=$(( "$test_end_tx_packets" - "$test_start_tx_packets" ))

# get_iface_rx_bytes $local_iface
# get_iface_tx_bytes $local_iface
# get_iface_rx_packets $local_iface
# get_iface_tx_packets $local_iface

	if [ ! -z "$write_csv_header" ]; then
		local header="Tests run number,Tests run time (s),Method,Volatility,Latency (ms),Xfer rate (mbit/s),Boot time (s),RX bytes,TX bytes,RX packets,TX packets,"$(head -n 1 "$results_path/diskspd")
		echo "$header" > "$results_csv"
		write_csv_header=
	fi
	
	local boottime=$(cat "$results_path/boottime")
	local csv_line_prefix="$tests_run_number,$test_time,$method,$volatility,$latency,${xfer_rate//mbit/},$boottime,$test_rx_bytes,$test_tx_bytes,$test_rx_packets,$test_tx_packets,"
	
	while IFS='' read -r csv_line; do
		echo "$csv_line_prefix$csv_line" >> "$results_csv"
	done <<< $(tail -n +2 "$results_path/diskspd")
	
# 	rm "$results_path/diskspd"
# 	rm "$results_path/boottime"

	tests_run_number=$(( $tests_run_number + 1 ))
	echo "--== Test finished in $test_time seconds"
}

if ! ping -c 1 -W 1 "$remote_address" &>/dev/null; then
	echo "--== Remote address $remote_address is unreachable"
	exit 1
fi

killall nc &>/dev/null || true
mkdir -p "$results_path"
#remote_collect_machine_info

# tc qdisc add dev $local_iface root handle 1: netem delay 0ms
# tc qdisc add dev $local_iface parent 1: tbf rate 100mbit latency 200ms burst 131072
# tc qdisc del dev $local_iface parent 1: tbf rate 100mbit latency 200ms burst 131072
# tc qdisc del dev $local_iface root netem

# exit 0

if start_servers; then
	remote_umount_all &>/dev/null
	if remote_mount_all; then
		echo "--== Starting!"
		for method in smb ; do # local nbd nfs 
# 			run_test nbd non-volatile 0 100mbits || true
# 			read junk
# 			break

			if [ "$method" = "local" ]; then
				echo "--== Initializing data for 'local' method"
				
				if ! remote_cmd "cp -n /mnt/data_smb/disk.raw /mnt/data_local/"; then
					echo "--== Failed to initialize data, skipping test"
				
					continue
				fi
			fi
			
			for volatility in  volatile-slow; do # non-volatile volatile
				for latency in 0 5 10 15; do # 
					if [ ! "$latency" = "0" ] && [ "$method" = "local" ]; then
						echo "--== Skipping latency $latency for local method"
						continue
					fi
					#[ "$latency" = "0" ] || 
				
					if ! tc qdisc add dev $local_iface root handle 1: netem delay ${latency}ms; then
						echo "--== Failed to set latency $latency, skipping test"
						continue
					fi
					
					for xfer_rate in 25mbit 50mbit 75mbit 100mbit 150mbit 200mbit 1000mbit; do #
						if [ ! "$xfer_rate" = "1000mbit" ] && [ "$method" = "local" ]; then
							echo "--== Skipping transfer rate $xfer_rate for local method"
				
							continue
						fi
						[ "$xfer_rate" = "0" ] || if ! tc qdisc add dev $local_iface parent 1: tbf rate $xfer_rate latency 200ms burst 131072; then
							echo "--== Failed to set transfer rate $xfer_rate, skipping test"
				
							continue
						fi
						[ "$xfer_rate" = "0" ] || if ! remote_cmd tc qdisc add dev $remote_iface root tbf rate $xfer_rate latency 200ms burst 131072; then
							echo "--== Failed to set transfer rate $xfer_rate on remote machine, skipping test"
				
							continue
						fi
						
						run_test $method $volatility $latency $xfer_rate || true
						
						[ "$xfer_rate" = "0" ] || remote_cmd tc qdisc del dev $remote_iface root tbf rate $xfer_rate latency 200ms burst 131072 || true
						[ "$xfer_rate" = "0" ] || tc qdisc del dev $local_iface parent 1: tbf rate $xfer_rate latency 200ms burst 131072 || true
					done
					
					#[ "$latency" = "0" ] || 
					tc qdisc del dev $local_iface root netem || true
# 					break
				done
# 				break
			done
# 			break
		done
	fi
	remote_umount_all
fi
stop_servers

chown -R 1000:1000 "$results_path"

echo "Done!"
